<?php
/**
 * Privacy Element Preview.
 *
 * @package Avada-Core
 * @since 3.5.2
 */

?>
<script type="text/template" id="fusion-builder-block-module-privacy-preview-template">
	<h4 class="fusion_module_title"><span class="fusion-module-icon {{ fusionAllElements[element_type].icon }}"></span>{{ fusionAllElements[element_type].name }}</h4>
</script>
